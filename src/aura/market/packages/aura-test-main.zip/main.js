// 测试插件: 验证主进程运行时的各项能力
let heartbeatTimer = null;
let tickCount = 0;

module.exports = {
  onLoad(ctx) {
    ctx.logger.log("onLoad: 测试主进程插件已加载, Aura 版本", ctx.auraVersion);

    // 1) 配置热读
    const config = ctx.config.get();
    ctx.logger.log("config 可读:", Boolean(config && config.auraSettings));

    // 2) storageDir 私有可写目录 + 持久化设置
    const fs = require("fs");
    const path = require("path");
    const bootFile = path.join(ctx.storageDir, "boot.json");
    fs.writeFileSync(
      bootFile,
      JSON.stringify({ loadedAt: new Date().toISOString(), auraVersion: ctx.auraVersion }, null, 2)
    );
    ctx.logger.log("storageDir 写入成功:", bootFile);
    ctx.logger.log("已保存的插件设置:", JSON.stringify(ctx.settings.get()));

    // 3) 事件总线订阅 (配置刷新 / 设置保存都会打点)
    if (ctx.eventBus && ctx.eventBus.on) {
      ctx.eventBus.on("$aura.config.refreshConfig", () => {
        ctx.logger.log("eventBus: 收到配置刷新事件");
      });
      ctx.eventBus.on("$aura.plugin." + ctx.manifest.id + ".settingsChanged", (values) => {
        ctx.logger.log("eventBus: 设置已更新", JSON.stringify(values));
      });
      ctx.logger.log("eventBus 订阅成功");
    }

    // 4) central 可用性探测 (不实际调用管家模块)
    ctx.logger.log("central 类型:", typeof ctx.central);

    // 5) 心跳: 证明插件持续存活; onUnload 时清理
    const settings = ctx.settings.get();
    const intervalMs = (Number(settings.heartbeatSeconds) > 0 ? Number(settings.heartbeatSeconds) : 60) * 1000;
    heartbeatTimer = setInterval(() => {
      tickCount += 1;
      ctx.logger.log("heartbeat #" + tickCount);
    }, intervalMs);
    ctx.logger.log("心跳已启动 (" + intervalMs + "ms 间隔)");
  },

  onUnload() {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
    console.log("[HugoAura / Plugin:com.aura.test.main] onUnload: 心跳定时器已清理");
  },
};