// 测试插件: 验证主进程沙箱运行时的各项能力 (无 require/fs/central)
var savedCtx = null;
var heartbeatTimer = null;
var tickCount = 0;

module.exports = {
  onLoad(ctx) {
    savedCtx = ctx;
    ctx.logger.log("onLoad: 测试主进程插件已加载 (vm 沙箱), Aura 版本", ctx.auraVersion);

    // 1) 配置只读快照 (settingsPassword* 已脱敏)
    var config = ctx.config.get();
    ctx.logger.log("config 可读:", Boolean(config && config.auraSettings));

    // 2) 插件私有设置: 宿主持久化到 storage/settings.json (无文件系统访问)
    ctx.logger.log("已保存的插件设置:", JSON.stringify(ctx.settings.get()));
    ctx.settings.set({
      lastLoadedAt: new Date().toISOString(),
      auraVersion: ctx.auraVersion,
    });
    ctx.logger.log("设置已写回 (storage 权限)");

    // 3) 事件总线: 仅可订阅/发布自己命名空间 ($aura.plugin.<id>.*)
    ctx.eventBus.on(
      "$aura.plugin." + ctx.manifest.id + ".settingsChanged",
      function (valuesJson) {
        ctx.logger.log("eventBus: 设置已更新", valuesJson);
      }
    );
    ctx.logger.log("eventBus 订阅成功 (命名空间: $aura.plugin." + ctx.manifest.id + ".* )");

    // 4) 心跳: 沙箱定时器 (上限 16 个, 卸载时宿主强制回收)
    var settings = ctx.settings.get();
    var intervalMs = (Number(settings.heartbeatSeconds) > 0 ? Number(settings.heartbeatSeconds) : 60) * 1000;
    heartbeatTimer = ctx.timers.setInterval(function () {
      tickCount += 1;
      ctx.logger.log("heartbeat #" + tickCount);
    }, intervalMs);
    ctx.logger.log("心跳已启动 (" + intervalMs + "ms 间隔)");
  },

  onUnload() {
    if (heartbeatTimer && savedCtx) {
      savedCtx.timers.clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }
  },
};