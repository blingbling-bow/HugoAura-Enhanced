// 测试插件: 验证 UI 沙箱运行时 (声明式 DOM 桥 + IPC 白名单)
module.exports = {
  onLoad(ctx) {
    var badgeId = ctx.dom.createEl("div", {
      style:
        "position:fixed;left:12px;bottom:12px;z-index:2147483646;" +
        "background:rgba(33,143,255,0.92);color:#fff;padding:6px 12px;" +
        "border-radius:999px;font:12px 'Microsoft YaHei',sans-serif;" +
        "box-shadow:0 4px 14px rgba(0,0,0,0.25);cursor:pointer;user-select:none;",
      title: "com.aura.test.ui — 点击测试 IPC",
    });
    ctx.dom.setText(badgeId, "Aura UI 插件已加载 (沙箱) ✓ v" + ctx.manifest.version);
    ctx.dom.appendToBody(badgeId);

    ctx.dom.on(badgeId, "click", function () {
      ctx.ipc.invoke("$aura.plugin.list").then(function (res) {
        var count = res && res.success ? (res.data || []).length : "?";
        ctx.dom.setText(badgeId, "插件列表: " + count + " 个");
      });
    });

    ctx.logger.log("徽章已挂载 (DOM 桥)");
  },
};
