// 测试插件: 验证渲染层运行时 (DOM 注入 + IPC)
module.exports = {
  onLoad(ctx) {
    const mount = () => {
      if (document.getElementById("auraTestUiPluginBadge")) return;
      const badge = document.createElement("div");
      badge.id = "auraTestUiPluginBadge";
      badge.style.cssText =
        "position:fixed;left:12px;bottom:12px;z-index:2147483646;" +
        "background:rgba(33,143,255,0.92);color:#fff;padding:6px 12px;" +
        "border-radius:999px;font:12px 'Microsoft YaHei',sans-serif;" +
        "box-shadow:0 4px 14px rgba(0,0,0,0.25);cursor:pointer;user-select:none;";
      badge.textContent = "Aura UI \u63d2\u4ef6\u5df2\u52a0\u8f7d \u2713 v" + ctx.manifest.version;
      badge.title = "com.aura.test.ui \u2014 \u70b9\u51fb\u6d4b\u8bd5 IPC";
      badge.onclick = async () => {
        try {
          const res = await ctx.ipcRenderer.invoke("$aura.plugin.list");
          badge.textContent =
            "插件列表: " + (res && res.success ? (res.data || []).length : "?") + " 个";
        } catch (err) {
          badge.textContent = "IPC 调用失败";
        }
      };
      (document.body || document.documentElement).appendChild(badge);
      console.log("[HugoAura / UIPlugin:com.aura.test.ui] 徽章已挂载");
    };

    if (document.body) mount();
    else document.addEventListener("DOMContentLoaded", mount);
  },
};
